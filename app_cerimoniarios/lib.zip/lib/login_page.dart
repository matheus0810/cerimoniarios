import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'register_page.dart';
import 'admin_home_page.dart';
import 'home_page.dart';
import 'firebase_token_handler.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String email = '';
  String senha = '';
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    verificarLogin();
  }

  void verificarLogin() async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('usuarios')
            .doc(user.uid)
            .get();

        final dados = doc.data();

        // ✅ Validação segura contra null
        if (dados == null || !dados.containsKey('funcao')) {
          print('❌ Documento do usuário não possui dados ou funcao');
          return;
        }

        FirebaseTokenHandler.salvarTokenFCM();

        if (dados['funcao'] == 'coordenador') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => AdminHomePage()),
          );
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => HomePage()),
          );
        }
      }
    });
  }

  void login() async {
    if (_formKey.currentState!.validate()) {
      try {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: senha,
        );
        verificarLogin(); // Redireciona após login
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro: ${e.toString()}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'E-mail'),
                onChanged: (val) => email = val,
                validator: (val) =>
                    !val!.contains('@') ? 'Informe um e-mail válido' : null,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Senha'),
                obscureText: true,
                onChanged: (val) => senha = val,
                validator: (val) =>
                    val!.length < 6 ? 'Senha muito curta' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: login, child: Text('Entrar')),
              TextButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => RegisterPage()));
                },
                child: Text('Criar conta'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
